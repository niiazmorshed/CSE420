int func() {

    int a;

    if (a>1){
        float a;

        if (a>1) {
            int a;

             if (a>1) {
                float a;

                if (a>1) {
                    int a;

                    if (a>1) {
                        float a;
                    }
                }
             }
        }
    }
}